ARCADIC — RETRO GAMING WEBSITE

Files
- index.html       Home page
- gaming.html      Mini arcade games + high-score boards
- shop.html        Shop, product detail popups and cart
- blog.html        Community blog
- history.html     Retro gaming history timeline
- signup.html      Account creation
- login.html       Login
- profile.html     Player profile, avatar selection and points
- script.js        Site interactions, accounts, shop, games, popups and local storage
- style.css        Retro visual design and responsive mobile layout

Games
- Space Invaders — keyboard/touch controls
- Pac-Man — keyboard/touch controls
- Ping Pong — keyboard/touch controls

Account demo
- Account data, arcade points, cart, blog posts and high scores are stored in this browser using localStorage.
- Three retro avatars are available: Alien 👾, Joystick 🕹️ and Floppy 💾.
- This is a front-end demonstration, not production authentication.

Popups
- First visit: a retro cookie-consent popup appears and remembers the choice.
- Visitors who are not logged in can also see a retro sign-up/login prompt. It can be dismissed.
- No tracking cookies are used by the site; the consent cookie only remembers the user's preference.

Mobile
- The desktop navigation becomes a hamburger menu below 800px.
- Game canvases resize to fit smaller screens.
- Touch controls appear on mobile for all three games.

Shop
- Click a product to view a detailed retro product listing.
- Cart data is stored locally. Checkout is a demonstration only; no payment is processed.

Browser support
- Use a modern browser with JavaScript enabled.
